
public class main {
	
	public static void main(String[] args) {
			Window game = new Window();
			game.setVisible(true);
	}		
}